-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2019 at 07:23 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `customersconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author`, `title`, `content`, `datetime`) VALUES
(0000000001, 'imadzamani', 'opening new branch', 'hi customers i am here to let you know that i''ve opened another branch which we is around zoo road opposite shopright', '2019-05-02 12:04:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `location` varchar(255) NOT NULL,
  `localgovt` varchar(255) NOT NULL,
  `bname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tbname` varchar(100) NOT NULL,
  `sbname` varchar(255) NOT NULL,
  `octime` varchar(100) NOT NULL,
  `joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `phone`, `location`, `localgovt`, `bname`, `password`, `tbname`, `sbname`, `octime`, `joined`) VALUES
(0000000001, 'Ibrahim |hassa muhammad', '08123251038', 'unguwa uku', 'tarauni', 'Trading', '123456', '', '', '', '2019-05-01 15:04:59'),
(0000000008, 'Bala Limawa', '07080792466', 'limawa hotoro behind zenith bank', 'tarauni', 'barbing saloon', 'dangadancy', 'we have some branches', 'we do any kind of hair cut', '8:00pm to 12:00am', '2019-05-02 11:43:51'),
(0000000009, 'taufeeq', '09099999999', '54-56 cbn quaters hotoro ', 'tarauni', 'photocopy printing laminating', 'dangadancy', '', '', '', '2019-05-02 01:37:15');
