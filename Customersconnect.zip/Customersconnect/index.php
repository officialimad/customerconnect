<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}


?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['phone'])) {
  $loginUsername=$_POST['phone'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "dashboard.php";
  $MM_redirectLoginFailed = "login.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_connect, $connect);
  
  $LoginRS__query=sprintf("SELECT phone, password FROM users WHERE phone=%s AND password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $connect) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO users (fullname, phone, location, localgovt, bname, password) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['fullname'], "text"),
                       GetSQLValueString($_POST['phone'], "text"),
                       GetSQLValueString($_POST['location'], "text"),
                       GetSQLValueString($_POST['localgovt'], "text"),
                       GetSQLValueString($_POST['bname'], "text"),
                       GetSQLValueString($_POST['password'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());

  $insertGoTo = "login2.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

$maxRows_post = 7;
$pageNum_post = 0;
if (isset($_GET['pageNum_post'])) {
  $pageNum_post = $_GET['pageNum_post'];
}
$startRow_post = $pageNum_post * $maxRows_post;

mysql_select_db($database_connect, $connect);
$query_post = "SELECT author, title, content, `datetime` FROM posts ORDER BY id DESC";
$query_limit_post = sprintf("%s LIMIT %d, %d", $query_post, $startRow_post, $maxRows_post);
$post = mysql_query($query_limit_post, $connect) or die(mysql_error());
$row_post = mysql_fetch_assoc($post);

if (isset($_GET['totalRows_post'])) {
  $totalRows_post = $_GET['totalRows_post'];
} else {
  $all_post = mysql_query($query_post);
  $totalRows_post = mysql_num_rows($all_post);
}
$totalPages_post = ceil($totalRows_post/$maxRows_post)-1;

$queryString_post = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_post") == false && 
        stristr($param, "totalRows_post") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_post = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_post = sprintf("&totalRows_post=%d%s", $totalRows_post, $queryString_post);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Connect</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Modal--Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/simple-footer.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
           
        <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
            <div class="container"><a class="navbar-brand" href="index.php">Customers Connect</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse"
                    id="navcol-1">
                    
                    <form class="form-inline mr-auto" target="_self">
                        <div class="form-group"></div>
                    </form>

                    <!-- Button trigger modal -->
                    <a href="index.php">Home</a>&nbsp; &nbsp; &nbsp; 
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalScrollable">
  Signup
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle" style="color:#000;">REGISTER YOUR BUSINESS HERE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  
    <input type="text" name="fullname" value="" class="form-control form-control-sm" placeholder="Full Name" /><br>
    
      <input type="text" name="phone" value="" class="form-control form-control-sm" placeholder="Enter Your Phone Number" /><br>
   
      <input type="text" name="location"  class="form-control form-control-sm" placeholder="Enter Your Business Location Address" /><br>
          <input type="text" name="localgovt" value="" class="form-control form-control-sm" placeholder="Enter Your Local Govt" /><br>
    
      <input type="text" name="bname" value="" class="form-control form-control-sm" placeholder="Enter Your What You Sell e.g Awara" /><br>
      <input type="password" name="password" value="" class="form-control form-control-sm" placeholder="Enter Your Phone Password" /><br>
         <input type="submit" value="Register" class="btn btn-outline-success" />
   
  <input type="hidden" name="MM_insert" value="form1" />
</form>

      </div>
      <div class="modal-footer">
        </div>
    </div>
  </div>
</div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <!--signup modal start-->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-sm">Login Here</button>

<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
   <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle" style="color:#000;">USERS LOGIN</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <form action="<?php echo $editFormAction; ?><?php echo $loginFormAction; ?>" method="POST" name="form1" id="form1">
      
          <input type="text" name="phone" value="" class="form-control form-control-sm" placeholder="Enter Your Phone Number" /><br>

          <input type="password" name="password" value="" class="form-control form-control-sm" placeholder="Enter Your Password" /><br>
         <input type="submit" value="Sign In" class="btn btn-outline-success" /><br>
       
      <input type="hidden" name="MM_insert" value="form1" />
  </form>
         
    
    <!-- end .content --></div>
      </div>
      <div class="modal-footer">
        
        
      </div>
    </div>
  </div>
</div>

 <!--signup modal end of it-->
            </div>
        </nav>
        <div class="container hero">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h1 class="text-center">Connect with what you want.</h1>
                </div>
            </div>
        </div>
       
        <form class="search-form" name="search" id="search" method="post" action="result_page.php">
            <div class="input-group">
                <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-search"></i></span></div><input class="form-control" name="txt_search" id="txt_search" type="text" placeholder="I am looking for.." required style="height:auto; border: solid thin #Fff; color:#FFF; background-color:transparent;" autocomplete>
                <div class="input-group-append"><input class="btn btn-light" type="submit" id="btn_search" value="Search"></div>
            </div>
        </form>
        <div class="profile-card">
            <div class="profile-back"></div><img class="rounded-circle profile-pic" src="assets/img/2.jpg">
            <h3 class="profile-name">About Customers Connect</h3>
            <p class="profile-bio" style="color:#fff;">Welcome to customers connect, customers connect is a platform design and implement to help and ease the difficulties of connect with what you want buy in a local community. We make this platform simple that a business man need to register his business under this platform for free so that when customers search something related to your business it will be listed in result page, the customer can take you contact and call you either to places the goods or he can come and meet you. </p>
            <ul class="social-list">
                <li> <i class="fa fa-facebook-official"></i></li>
                <li> <i class="fa fa-twitter-square"></i></li>
                <li> <i class="fa fa-linkedin-square"></i></li>
            </ul>
        </div>
        <h3 class="profile-name" style="text-align: center;">Latest updates from local business</h3><blockquote class="quote-card">
       <p>  <h4> Page <?php echo ($startRow_post + 1) ?> of <?php echo min($startRow_post + $maxRows_post, $totalRows_post) ?></h4>
       <?php do { ?>
       Author Name : 
       <?php echo $row_post['author']; ?><br>
         Tittle Of Post : <?php echo $row_post['title']; ?><br>
         Tittle Of Post : <?php echo $row_post['content']; ?><br>
         Time Posted : <?php echo $row_post['datetime']; ?><br>
  <?php } while ($row_post = mysql_fetch_assoc($post)); ?>
</p>
<a href="<?php printf("%s?pageNum_post=%d%s", $currentPage, max(0, $pageNum_post - 1), $queryString_post); ?>">Previous</a> &nbsp;  &nbsp;  &nbsp;<a href="<?php printf("%s?pageNum_post=%d%s", $currentPage, min($totalPages_post, $pageNum_post + 1), $queryString_post); ?>">Next</a></div>
    </div>
    <div class="footer-2">
        <div class="container">
            <div class="row">
                <div class="col-8 col-sm-6 col-md-6">
                    <p class="text-left" style="margin-top:5%;margin-bottom:3%; color: #fff;">© 2019 Customers Connect | DSCFACPT</p>
                </div>
                <div class="col-12 col-sm-6 col-md-6">
                    <p style="margin-top:5%;margin-bottom:8%%;font-size:1em; color: #fff;">Privacy Policy</p>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<?php
mysql_free_result($post);
?>
