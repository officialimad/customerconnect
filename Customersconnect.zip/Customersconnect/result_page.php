<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_search = 15;
$pageNum_search = 0;
if (isset($_GET['pageNum_search'])) {
  $pageNum_search = $_GET['pageNum_search'];
}
$startRow_search = $pageNum_search * $maxRows_search;

$colname_search = "-1";
mysql_select_db($database_connect, $connect);
if (isset($_POST['txt_search'])) {
  $searchword = $_POST['txt_search'];
  $query_search = "SELECT * FROM users WHERE  bname like '%".$searchword."%' ";

}
$query_limit_search = sprintf("%s LIMIT %d, %d", $query_search, $startRow_search, $maxRows_search);
$search = mysql_query($query_limit_search, $connect) or die(mysql_error());
$row_search = mysql_fetch_assoc($search);

if (isset($_GET['totalRows_search'])) {
  $totalRows_search = $_GET['totalRows_search'];
} else {
  $all_search = mysql_query($query_search);
  $totalRows_search = mysql_num_rows($all_search);
}
$totalPages_search = ceil($totalRows_search/$maxRows_search)-1;

$queryString_search = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_search") == false && 
        stristr($param, "totalRows_search") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_search = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_search = sprintf("&totalRows_search=%d%s", $totalRows_search, $queryString_search);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Connect</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Modal--Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/simple-footer.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
           
       
                    
                    

                    <!-- Button trigger modal -->
                  
<style>
.box1{
	width:50%;
	margin:auto;
	background-color:#fff;
	color:#000;
	height:auto;
	border-radius:10px;
	}
	
</style>
<h1>&nbsp;</h1>
<a href="index.php">Back To Home</a><br>
 <form class="search-form" name="search" id="search" method="post" action="result_page.php">
            <div class="input-group">
                <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-search"></i></span></div><input class="form-control" name="txt_search" id="txt_search" type="text" placeholder="I am looking for.." required style="height:auto; border: solid thin #Fff; color:#FFF; background-color:transparent;" autocomplete>
                <div class="input-group-append"><input class="btn btn-light" type="submit" id="btn_search" value="Search"></div>
            </div>
        </form>
<div class=" quote-card">
 <div class="alert alert-dismissible alert-success alert" align="center"> <?php echo $totalRows_search ?> Matching Result Found.</div>
 
 Page <?php echo ($startRow_search + 1) ?> of <?php echo min($startRow_search + $maxRows_search, $totalRows_search) ?>
<h5>&nbsp;  </h5>

   <?php do { ?>
     Business <?php echo $row_search['bname']; ?><br>
     Business Adress <?php echo $row_search['location']; ?><br>
      
      Business Owner <?php echo $row_search['fullname']; ?><br>
       Contact <?php echo $row_search['phone']; ?><br>
       
      
       
        <a href="result_page_details.php?id=<?php echo $row_search['id']; ?>">View Details</a><br><hr>
     
     <?php } while ($row_search = mysql_fetch_assoc($search)); ?>

<a href="<?php printf("%s?pageNum_search=%d%s", $currentPage, max(0, $pageNum_search - 1), $queryString_search); ?>">Previous</a> &nbsp; &nbsp; &nbsp;<a href="<?php printf("%s?pageNum_search=%d%s", $currentPage, min($totalPages_search, $pageNum_search + 1), $queryString_search); ?>">Next</a></div>
  <h1>&nbsp;</h1>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<?php
mysql_free_result($search);
?>
