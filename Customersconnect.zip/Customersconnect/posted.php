<?php require_once('Connections/connect.php'); ?>
<?php

// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
  $_SESSION['MM_Username'];
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO posts (author, title, content) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['author'], "text"),
                       GetSQLValueString($_POST['title'], "text"),
                       GetSQLValueString($_POST['content'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());

  $insertGoTo = "posted.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

$maxRows_details = 1;
$pageNum_details = 0;
if (isset($_GET['pageNum_details'])) {
  $pageNum_details = $_GET['pageNum_details'];
}
$startRow_details = $pageNum_details * $maxRows_details;

$colname_details = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_details = $_SESSION['MM_Username'];
}
mysql_select_db($database_connect, $connect);
$query_details = sprintf("SELECT * FROM users WHERE phone = %s", GetSQLValueString($colname_details, "text"));
$query_limit_details = sprintf("%s LIMIT %d, %d", $query_details, $startRow_details, $maxRows_details);
$details = mysql_query($query_limit_details, $connect) or die(mysql_error());
$row_details = mysql_fetch_assoc($details);

if (isset($_GET['totalRows_details'])) {
  $totalRows_details = $_GET['totalRows_details'];
} else {
  $all_details = mysql_query($query_details);
  $totalRows_details = mysql_num_rows($all_details);
}
$totalPages_details = ceil($totalRows_details/$maxRows_details)-1;



?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Connect</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Modal--Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/simple-footer.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
           
        <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
            <div class="container"><a class="navbar-brand" href="index.php">Customers Connect</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse"
                    id="navcol-1">
                    
                    <form class="form-inline mr-auto" target="_self">
                        <div class="form-group"></div>
                    </form>

                   
                   <a href="dashboard.php">Home</a>&nbsp; &nbsp; 
                   <a href="profile.php?id=<?php echo $row_details['id']; ?>">Profile</a>&nbsp; &nbsp; 
                    <a href="update.php?id=<?php echo $row_details['id']; ?>">Update Profile</a>&nbsp; &nbsp; 
                   
      </div>
    </div>
  </div>
</div>
 
       
                    
                    

                    <!-- Button trigger modal -->
                  
<style>
.box1{
	width:50%;
	margin:auto;
	background-color:#fff;
	color:#000;
	height:auto;
	border-radius:10px;
	}
	
</style>
<h1>&nbsp;</h1>

 
<div class=" quote-card">
 <div class="alert alert-dismissible alert-success alert" align="center"><?php echo $row_details['fullname']; ?> your post successfully published </div>
 <h3>&nbsp;</h3>
 <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
   
       <input type="text" name="author" value="" class=" form-control form-control-sm" placeholder="Enter  Author Name"><br>
    
       <input type="text" name="title" value="" class=" form-control form-control-sm" placeholder="Enter Tittle Of Your Post"><br>
    
       <textarea name="content" class=" form-control form-control-sm" placeholder="Enter Content, Not Morethan 200 Characters"></textarea><br>
     
       <input type="submit" value="Publish" class="btn btn-outline-success">
     
   <input type="hidden" name="MM_insert" value="form1">
 </form>
 <p>&nbsp;</p>
</div>
  <h1>&nbsp;</h1>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<?php
mysql_free_result($details);
?>
