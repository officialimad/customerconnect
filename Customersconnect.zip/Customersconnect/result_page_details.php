<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_details = 1;
$pageNum_details = 0;
if (isset($_GET['pageNum_details'])) {
  $pageNum_details = $_GET['pageNum_details'];
}
$startRow_details = $pageNum_details * $maxRows_details;

$colname_details = "-1";
if (isset($_GET['id'])) {
  $colname_details = $_GET['id'];
}
mysql_select_db($database_connect, $connect);
$query_details = sprintf("SELECT * FROM users WHERE id = %s", GetSQLValueString($colname_details, "int"));
$query_limit_details = sprintf("%s LIMIT %d, %d", $query_details, $startRow_details, $maxRows_details);
$details = mysql_query($query_limit_details, $connect) or die(mysql_error());
$row_details = mysql_fetch_assoc($details);

if (isset($_GET['totalRows_details'])) {
  $totalRows_details = $_GET['totalRows_details'];
} else {
  $all_details = mysql_query($query_details);
  $totalRows_details = mysql_num_rows($all_details);
}
$totalPages_details = ceil($totalRows_details/$maxRows_details)-1;
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Connect</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Modal--Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/Quote-Card.css">
    <link rel="stylesheet" href="assets/css/simple-footer.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="header-dark">
           
       
                    
                    

                    <!-- Button trigger modal -->
                  
<style>
.box1{
	width:50%;
	margin:auto;
	background-color:#fff;
	color:#000;
	height:auto;
	border-radius:10px;
	}
	
</style>
<h1>&nbsp;</h1>
<a href="index.php">Back To Home</a><br>
 <form class="search-form" name="search" id="search" method="post" action="result_page.php">
            <div class="input-group">
                <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-search"></i></span></div><input class="form-control" name="txt_search" id="txt_search" type="text" placeholder="I am looking for.." required style="height:auto; border: solid thin #Fff; color:#FFF; background-color:transparent;" autocomplete>
                <div class="input-group-append"><input class="btn btn-light" type="submit" id="btn_search" value="Search"></div>
            </div>
        </form>
<div class=" quote-card">
 <div class="alert alert-dismissible alert-success alert" align="center">Details Of  <?php echo $row_details['bname']; ?>.</div>

   <?php do { ?>
     
       
       Business Owner <?php echo $row_details['fullname']; ?><br>
      Contact  <?php echo $row_details['phone']; ?><br>
       Business Address <?php echo $row_details['location']; ?><br>
       Local Govt <?php echo $row_details['localgovt']; ?><br>
      
      
       <?php echo $row_details['tbname']; ?><br>
       <?php echo $row_details['sbname']; ?><br>
       Time Opening & Closing <?php echo $row_details['octime']; ?><br>
       Time Join <?php echo $row_details['joined']; ?><br>
     
     <?php } while ($row_details = mysql_fetch_assoc($details)); ?>
 
</div>
  <h1>&nbsp;</h1>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<?php
mysql_free_result($details);
?>
